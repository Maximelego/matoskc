# MatosKC.Infrastructure.Tests

Tests d’intégration de la persistance EF Core sur un véritable PostgreSQL
temporaire fourni par Testcontainers.

## Installation

Extraire directement le contenu de l’archive dans :

```text
backend/tests/MatosKC.Infrastructure.Tests/
```

Depuis `backend`, ajouter le projet à la solution si nécessaire :

```bash
dotnet sln MatosKC.slnx add tests/MatosKC.Infrastructure.Tests/MatosKC.Infrastructure.Tests.csproj
```

Puis lancer :

```bash
dotnet test tests/MatosKC.Infrastructure.Tests
```

Docker doit être démarré. Les tests créent leur propre conteneur PostgreSQL et
n’utilisent pas la base de développement.

## Hypothèses

- `MatosKCDbContext` se trouve dans `MatosKC.Infrastructure.Persistence`.
- Son constructeur reçoit `DbContextOptions<MatosKCDbContext>`.
- Les migrations EF Core se trouvent dans l’assembly Infrastructure.
- Le constructeur public d’`Equipment` accepte `(name, categoryId, serialNumber)`.

Si l’ordre du constructeur `Equipment` diffère, seules les trois lignes de sa
création dans `MatosKCDbContextTests.cs` sont à adapter.
