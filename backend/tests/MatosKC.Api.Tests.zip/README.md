# MatosKC.Api.Tests

Tests HTTP d’intégration utilisant `WebApplicationFactory` et un PostgreSQL
temporaire fourni par Testcontainers.

## Installation

Extraire directement le contenu de l’archive dans :

```text
backend/tests/MatosKC.Api.Tests/
```

Depuis `backend`, ajouter le projet à la solution si nécessaire :

```bash
dotnet sln MatosKC.slnx add tests/MatosKC.Api.Tests/MatosKC.Api.Tests.csproj
```

Ajouter également, tout en bas de `src/MatosKC.Api/Program.cs` :

```csharp
public partial class Program;
```

Puis lancer :

```bash
dotnet test tests/MatosKC.Api.Tests
```

Docker doit être démarré. Les tests créent leur propre conteneur PostgreSQL et
n’utilisent pas la base de développement.

## Contrat couvert

- `POST /api/equipment-categories` retourne `201 Created` et un identifiant.
- `GET /api/equipment-categories/{id}` retourne le DTO attendu.
- Une catégorie inconnue retourne `404` au format Problem Details.
- Un nom de catégorie vide retourne `400`.
- `POST /api/equipments` crée un équipement lié à une catégorie.
- Un `categoryId` JSON mal formé retourne `400`.

## Hypothèses

- Le nom de la connexion est `MatosKCDatabase`.
- `MatosKCDbContext` se trouve dans `MatosKC.Infrastructure.Persistence`.
- Les routes sont `/api/equipment-categories` et `/api/equipments`.
- Les réponses de création contiennent un champ JSON `id`.
- Les migrations EF sont présentes dans Infrastructure.

Ces points sont centralisés dans peu de fichiers afin de faciliter une éventuelle
adaptation aux noms exacts du projet.
